package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Observable;
import view.IGUI;

public class Tracker extends Observable implements ITracker {

	private ArrayList<IFolio> folios = new ArrayList<IFolio>();
	private IFolio currentFolio;
	
	
	public ArrayList<IFolio> getFolios() {
		return this.folios;
	}
	public IFolio getCurrFolio(){
		return this.currentFolio;
	}

	public IFolio openFile(File fileName, IGUI gui) throws FileNotFoundException {
		return null;
	}

	public void saveFile(IFolio currentFolio, String folioName) {
		
	}

	public void newFolio(IFolio folio, String folioName) {
		IFolio newFolio = new Folio(folioName);
		folios.add(newFolio);
		notifyObservers();
	}

	public void closeFolio(IFolio folio) {
		folios.remove(folio);
		notifyObservers();

	}

	public void refreshAllData() {
		for(IFolio f: folios){
			 f.refreshFolioData();
			}
	}



}

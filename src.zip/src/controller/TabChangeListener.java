package controller;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import model.ITracker;
import view.IGUI;

public class TabChangeListener implements ChangeListener {

	public TabChangeListener(IGUI gui, ITracker t) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		
	}
}


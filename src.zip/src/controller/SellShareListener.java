package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.ITracker;
import view.IGUI;

public class SellShareListener implements ActionListener {

	public SellShareListener(IGUI gui, ITracker t) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {		
	}
	
}
